const bookingModel = require("../models/booking");

const createBooking = async (req, res) => {
    try {
        const bookingData = req.body;

        // Check if required fields are present
        const { VehicleId, name, address, phone_num, FromDate, ToDate, Status } = bookingData;
        if (!VehicleId || !name || !address || !phone_num || !FromDate || !ToDate || !Status) {
            return res.status(400).json({ error: "All booking details are required" });
        }

        // Check for booking conflicts
        const conflict = await bookingModel.checkBookingConflict(VehicleId, FromDate, ToDate);
        if (conflict) {
            return res.status(409).json({ error: `The car is already booked from ${FromDate} to ${ToDate}. Please choose another date.` });
        }

        // Call the function to create the booking
        const result = await bookingModel.createBooking(bookingData);

        // Send success response
        res.status(201).json({ message: "Booking created", bookingId: result.insertId });
    } catch (error) {
        console.error("Error in createBooking:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const getAllBookings = async (req, res) => {
    try {
        const bookings = await bookingModel.getAllBookings();
        res.json(bookings);
    } catch (error) {
        console.error("Error in getAllBookings:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const getBookingById = async (req, res) => {
    try {
        const id = req.params.id;
        const booking = await bookingModel.getBookingById(id);
        if (booking) {
            res.json(booking);
        } else {
            res.status(404).json({ message: "Booking not found" });
        }
    } catch (error) {
        console.error("Error in getBookingById:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};
const updateBooking = async (req, res) => {
    try {
        const { id } = req.params;
        const bookingData = req.body;

        // Check if required fields are present
        const { VehicleId, name, address, phone_num, cash, FromDate, ToDate, Status } = bookingData;
        if (!VehicleId || !name || !address || !phone_num || !cash || !FromDate || !ToDate || !Status) {
            return res.status(400).json({ error: "All booking details are required" });
        }

        // Check if the booking exists
        const existingBooking = await bookingModel.getBookingById(id);
        if (!existingBooking) {
            return res.status(404).json({ error: "Booking not found" });
        }

        // Call the function to update the booking
        await bookingModel.updateBooking(id, bookingData);

        // Send success response
        res.json({ message: "Booking updated successfully" });
    } catch (error) {
        console.error("Error in updateBooking:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const deleteBooking = async (req, res) => {
    const { id } = req.params;

    try {
        await bookingModel.deleteBooking(id);
        res.json({ success: true, message: "Booking deleted successfully" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: "Internal Server Error" });
    }
};

module.exports = {
    createBooking,
    getAllBookings,
    getBookingById,
    deleteBooking,
    updateBooking
};
