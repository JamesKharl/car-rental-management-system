const accountModel = require("../models/accounts");
const bcrypt = require('bcrypt');

const loginUser = async (req, res) => {
    const { username, password } = req.body;

    try {
        const users = await accountModel.getUsers(username);
        if (users.length > 0) {
            const user = users[0];
            // Compare hashed password
            const match = await bcrypt.compare(password, user.Password);
            if (match) {
                res.json({ success: true, message: "User authenticated", user });
            } else {
                res.status(401).json({ success: false, message: "Wrong password" });
            }
        } else {
            res.status(404).json({ success: false, message: "No user found" });
        }
    } catch (error) {
        console.error("Error logging in:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const createAccount = async (req, res) => {
    try {
        const { username, password } = req.body;

        // Basic validation
        if (!username || !password) {
            return res.status(400).json({ error: 'Username and password are required' });
        }

        // Call the model function to create the account
        const result = await accountModel.createAccount(username, password);

        // Send a success response
        res.status(201).json({ message: 'Account created successfully', result });
    } catch (error) {
        // If an error occurs, send an error response
        console.error("Error creating account:", error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const getAccountById = async (req, res) => {
    try {
        const id = req.params.id;
        const account = await accountModel.getAccountById(id);
        if (account) {
            res.json(account);
        } else {
            res.status(404).json({ message: "Account not found" });
        }
    } catch (error) {
        console.error("Error in getAccountById:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const updateAccount = async (req, res) => {
    try {
        const { id } = req.params; // ID from the URL parameter
        const { username, password } = req.body; // Account data from the request body

        const existingAccount = await accountModel.getAccountById(id);
        if (!existingAccount) {
            return res.status(404).json({ message: "Account not found" });
        }

        // Hash the password if provided
        if (password) {
            const hashedPassword = await bcrypt.hash(password, 10);
            existingAccount.Password = hashedPassword;
        }

        // Call the model function to update the account in the database
        const updateResults = await accountModel.updateAccount(id, existingAccount);
        if (updateResults.affectedRows === 0) {
            return res.status(404).json({ message: "No rows updated; account not found" });
        }

        res.json({ message: "Account updated" });
    } catch (error) {
        console.error("Error in updateAccount controller:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

module.exports = {
    createAccount,
    loginUser,
    getAccountById,
    updateAccount,
}; 
