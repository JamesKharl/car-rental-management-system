const vehicleModel = require("../models/vehicles");

const createVehicle = async (req, res) => {
    try {
        const vehicleData = req.body;

        // Check if required fields are present
        if (!vehicleData.name || !vehicleData.brand_id) {
            return res.status(400).json({ error: "Vehicle name and brand ID are required" });
        }

        // Call the function to create the vehicle
        const result = await vehicleModel.createVehicle(vehicleData);

        // Send success response
        res.status(201).json({ message: "Vehicle created", vehicleId: result.insertId });
    } catch (error) {
        console.error("Error in createVehicle:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const getAllVehicle = async (req, res) => {
    try {
      const vehicles = await vehicleModel.getAllVehicle();
      res.json(vehicles);
    } catch (error) {
      console.error("Error in getAllVehicle:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  };

  const getVehicleId = async (req, res) => {
    try {
      const id = req.params.id;
      const vehicle = await vehicleModel.getVehicleId(id);
      if (vehicle) {
        res.json(vehicle);
      } else {
        res.status(404).json({ message: "Vehicle not found" });
      }
    } catch (error) {
      console.error("Error in getVehicleId:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  }; 

  const updateVehicle = async (req, res) => {
    try {
        const { id } = req.params; // ID from the URL parameter
        const vehicleData = req.body; // Vehicle data from the request body
  
        const existingVehicle = await vehicleModel.getVehicleId(id); // Assuming this function correctly fetches the vehicle or null if not found
        if (!existingVehicle) {
            return res.status(404).json({ message: "Vehicle not found" });
        }
  
        // Call the model function to update the vehicle in the database
        const updateResults = await vehicleModel.updateVehicle(id, vehicleData);
        if (updateResults.affectedRows === 0) {
            return res.status(404).json({ message: "No rows updated; vehicle not found" });
        }
  
        res.json({ message: "Vehicle updated" });
    } catch (error) {
        console.error("Error in updateVehicle controller:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

  const deleteVehicle = async (req, res) => {
    const { id } = req.params;

    try {
        await vehicleModel.deleteVehicle(id);
        res.json({ success: true, message: "Vehicle deleted successfully" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: "Internal Server Error" });
    }
}; 
module.exports = {createVehicle,getAllVehicle,getVehicleId,deleteVehicle,updateVehicle};

  