const brandModel = require("../models/brands");
  
  const createBrand = async (req, res) => {
    try {
      const brand = req.body;
      if (!brand.name) {
        return res.status(400).json({ error: "Brand name is required" });
      }
      const result = await brandModel.createBrand(brand);
      res.status(201).json({ message: "Brand created", brandId: result.insertId });
    } catch (error) {
      console.error("Error in createProduct:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  };

const getAllBrands = async (req, res) => {
    try {
      const brands = await brandModel.getAllBrands();
      res.json(brands);
    } catch (error) {
      console.error("Error in getAllBrands:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  };
const getBrandById = async (req, res) => {
    const { id } = req.params;

    try {
        const brand = await brandModel.getBrandById(id);
        if (brand) {
            res.json({ success: true, brand });
        } else {
            res.status(404).json({ success: false, error: "Brand not found" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: "Internal Server Error" });
    }
};

const updateBrand = async (req, res) => {
    const { id } = req.params;
    const { name } = req.body;

    try {
        const updatedBrand = await brandModel.updateBrand(id, name);
        res.json({ success: true, message: "Brand updated successfully", brand: updatedBrand });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: "Internal Server Error" });
    }
};

const deleteBrand = async (req, res) => {
    const { id } = req.params;

    try {
        await brandModel.deleteBrand(id);
        res.json({ success: true, message: "Brand deleted successfully" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: "Internal Server Error" });
    }
}; 

module.exports = { createBrand , getAllBrands, getBrandById, updateBrand, deleteBrand};
