// index.js
const express = require('express');
const accountRoutes = require('./routes/accountRoutes');
const brandsRoutes = require('./routes/brandsRoutes');
const vehicleRoutes = require('./routes/vehiclesRoutes');
const bookingRoutes = require('./routes/bookingRoutes');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;
// Increase the limit for JSON payloads (adjust the limit as needed)
app.use(bodyParser.json({ limit: '50mb' }));

// Increase the limit for URL-encoded payloads (adjust the limit as needed)
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(bodyParser.json());
app.use(cors());

// Corrected route setup
app.use('/api', accountRoutes);
app.use('/api', brandsRoutes);
app.use('/api', vehicleRoutes);
app.use('/api', bookingRoutes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
