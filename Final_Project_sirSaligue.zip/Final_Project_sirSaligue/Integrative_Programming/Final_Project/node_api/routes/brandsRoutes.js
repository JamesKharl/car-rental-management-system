const express = require('express');
const router = express.Router();
const brandsController = require('../controllers/brandsController');

// Routes for brand management
router.post('/brands', brandsController.createBrand);
router.get('/brands', brandsController.getAllBrands);
router.get('/brands/:id', brandsController.getBrandById);
router.put('/brands/:id', brandsController.updateBrand);
router.delete('/brands/:id', brandsController.deleteBrand); 

module.exports = router;