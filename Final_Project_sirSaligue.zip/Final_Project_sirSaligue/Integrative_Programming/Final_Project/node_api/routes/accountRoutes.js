const express = require('express');
const router = express.Router();
const userController = require('../controllers/accountsController');

// Route for user login
router.post('/user/login', userController.loginUser); // Matching the endpoint in C#
router.post('/user/create', userController.createAccount); // Matching the endpoint in C#
router.get('/users/:id', userController.getAccountById);
router.put('/user/:id', userController.updateAccount);

module.exports = router;

