const express = require('express');
const router = express.Router();
const createVehicle = require('../controllers/vehiclesController');
const getAllVehicle = require('../controllers/vehiclesController');
const getVehicleId = require('../controllers/vehiclesController');
const deleteVehicle = require('../controllers/vehiclesController');
const updateVehicle = require('../controllers/vehiclesController');


// Route for creating a new vehicle
router.post('/vehicle', createVehicle.createVehicle);
router.get('/vehicle', getAllVehicle.getAllVehicle);
router.get('/vehicle/:id', getVehicleId.getVehicleId);
router.delete('/vehicle/:id', deleteVehicle.deleteVehicle);
router.put('/vehicle/:id', updateVehicle.updateVehicle);

module.exports = router;
