const pool = require('../services/db');

const createVehicle = (vehicle) => {
  const { name, brand_id, details, price, fuel_type, model_year, seating_capacity, image, reg_date } = vehicle;
  return new Promise((resolve, reject) => {
    pool.query('INSERT INTO vehicles (name, brand_id, details, price, fuel_type, model_year, seating_capacity, image, reg_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', 
    [name, brand_id, details, price, fuel_type, model_year, seating_capacity, image, reg_date], (err, results) => {
      if (err) {
        console.error("Error creating vehicle:", err);
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
};

const updateVehicle = (id, vehicle) => {
  const { name, brand_id, details, price, fuel_type, model_year, seating_capacity, image, updation_date } = vehicle;
  return new Promise((resolve, reject) => {
    const sql = 'UPDATE vehicles SET name = ?, brand_id = ?, details = ?, price = ?, fuel_type = ?, model_year = ?, seating_capacity = ?, image = ?, updation_date = ? WHERE id = ?';
    pool.query(sql, [name, brand_id, details, price, fuel_type, model_year, seating_capacity, image, updation_date, id],
      (err, results) => {
        if (err) {
          console.error("Error updating vehicle:", err);
          reject(err);
        } else {
          resolve(results);
        }
      }
    );
  });
};

const getAllVehicle = () => {
  return new Promise((resolve, reject) => {
    pool.query('SELECT * FROM vehicles', (err, results) => {
      if (err) {
        console.error('Error fetching all brands:', err);
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
};


const getVehicleId = (id) => {
  return new Promise((resolve, reject) => {
    pool.query('SELECT * FROM vehicles WHERE id = ?', [id], (err, results) => {
      if (err) {
        console.error("Error fetching vehicle by ID:", err);
        reject(err);
      } else {
        resolve(results[0]); 
      }
    });
  });
};

const deleteVehicle = (id) => {
  return new Promise((resolve, reject) => {
    const sql = 'DELETE FROM vehicles WHERE id = ?';
    pool.query(sql, [id], (err, results) => {
      if (err) {
        console.error('Error deleting vehicle:', err);
        reject(err);
      } else {
        if (results.affectedRows > 0) {
          resolve({ message: 'Vehicle deleted successfully' });
        } else {
          reject({ error: 'Failed to delete vehicle' });
        }
      }
    });
  });
};


module.exports = {createVehicle,getAllVehicle,getVehicleId,deleteVehicle,updateVehicle};