const pool = require('../services/db');

const createBooking = (booking) => {
    const { VehicleId, name, address, phone_num, FromDate, ToDate, Status } = booking;
    return new Promise((resolve, reject) => {
        const sql = 'INSERT INTO tblbooking (VehicleId, name, address, phone_num, FromDate, ToDate, Status) VALUES (?, ?, ?, ?, ?, ?, ?)';
        pool.query(sql, [VehicleId, name, address, phone_num, FromDate, ToDate, Status], (err, results) => {
            if (err) {
                console.error("Error creating booking:", err);
                reject(err);
            } else {
                resolve(results);
            }
        });
    });
};

const getAllBookings = () => {
    return new Promise((resolve, reject) => {
        const sql = 'SELECT * FROM tblbooking';
        pool.query(sql, (err, results) => {
            if (err) {
                console.error('Error fetching all bookings:', err);
                reject(err);
            } else {
                resolve(results);
            }
        });
    });
};

const getBookingById = (id) => {
    return new Promise((resolve, reject) => {
        const sql = 'SELECT * FROM tblbooking WHERE id = ?';
        pool.query(sql, [id], (err, results) => {
            if (err) {
                console.error("Error fetching booking by ID:", err);
                reject(err);
            } else {
                resolve(results[0]);
            }
        });
    });
};

const updateBooking = (id, booking) => {
  const { VehicleId, name, address, phone_num, cash, FromDate, ToDate, Status } = booking;
  return new Promise((resolve, reject) => {
      const sql = 'UPDATE tblbooking SET VehicleId=?, name=?, address=?, phone_num=?, cash=?, FromDate=?, ToDate=?, Status=? WHERE id=?';
      pool.query(sql, [VehicleId, name, address, phone_num, cash, FromDate, ToDate, Status, id], (err, results) => {
          if (err) {
              console.error("Error updating booking:", err);
              reject(err);
          } else {
              resolve(results);
          }
      });
  });
};

const deleteBooking = (id) => {
    return new Promise((resolve, reject) => {
        const sql = 'DELETE FROM tblbooking WHERE id = ?';
        pool.query(sql, [id], (err, results) => {
            if (err) {
                console.error("Error deleting booking:", err);
                reject(err);
            } else {
                resolve(results);
            }
        });
    });
};

const checkBookingConflict = (VehicleId, FromDate, ToDate) => {
    return new Promise((resolve, reject) => {
        const sql = `SELECT COUNT(*) AS conflictCount FROM tblbooking 
                     WHERE VehicleId = ? AND 
                     ((FromDate <= ? AND ToDate >= ?) OR 
                      (FromDate <= ? AND ToDate >= ?) OR 
                      (FromDate >= ? AND ToDate <= ?))`;
        pool.query(sql, [VehicleId, FromDate, FromDate, ToDate, ToDate, FromDate, ToDate], (err, results) => {
            if (err) {
                console.error("Error checking booking conflict:", err);
                reject(err);
            } else {
                resolve(results[0].conflictCount > 0);
            }
        });
    });
};

module.exports = { createBooking, getAllBookings, getBookingById, deleteBooking, checkBookingConflict, updateBooking };
