const bcrypt = require('bcrypt');
const pool = require('../services/db');

const getUsers = (username, password) => {
  return new Promise((resolve, reject) => {
    // Add condition for role_id = 1
    pool.query(
      'SELECT * FROM admin WHERE UserName = ?',
      [username],
      (err, results) => {
        if (err) {
          console.error("Error selecting users:", err);
          reject(err);
        } else {
          resolve(results);
        }
      }
    );
  });
}

const getAccountById = (id) => {
  return new Promise((resolve, reject) => {
    pool.query('SELECT * FROM admin WHERE id = ?', [id], (err, results) => {
      if (err) {
        console.error("Error fetching account by ID:", err);
        reject(err);
      } else {
        resolve(results[0]); 
      }
    });
  });
};

const updateAccount = (id, accountData) => {
  const { username, password } = accountData;
  return new Promise((resolve, reject) => {
    const sql = 'UPDATE admin SET UserName =?, Password =? WHERE id = ?';
    pool.query(sql, [username, password, id],
      (err, results) => {
        if (err) {
          console.error("Error updating account:", err);
          reject(err);
        } else {
          resolve(results);
        }
      }
    );
  });
};

const createAccount = async (username, password) => {
  try {
    // Hash the password before storing it
    const hashedPassword = await bcrypt.hash(password, 10);
    const sql = 'INSERT INTO admin (UserName, Password) VALUES (?, ?)';
    const results = await pool.query(sql, [username, hashedPassword]);
    return results;
  } catch (err) {
    console.error("Error creating account:", err);
    throw err;
  }
};

module.exports = {
  getUsers,
  createAccount,
  getAccountById,
  updateAccount,
};
