// models/brands.js
const pool = require('../services/db');

  const createBrand = (brand) => {
    const { name, creation_date } = brand;
    return new Promise((resolve, reject) => {
      pool.query('INSERT INTO tblbrands (name, creation_date) VALUES (?, ?)', 
      [name, creation_date], (err, results) => {
        if (err) {
          console.error("Error creating brand:", err);
          reject(err);
        } else {
          resolve(results);
        }
      });
    });
  };
  
const getBrandById = (id) => {
  return new Promise((resolve, reject) => {
    pool.query('SELECT * FROM tblbrands WHERE id = ?', [id], (err, results) => {
      if (err) {
        console.error('Error fetching brand by ID:', err);
        reject(err);
      } else {
        resolve(results[0]);
      }
    });
  });
};

const getAllBrands = () => {
  return new Promise((resolve, reject) => {
    pool.query('SELECT * FROM tblbrands', (err, results) => {
      if (err) {
        console.error('Error fetching all brands:', err);
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
};

const updateBrand = (id, name) => {
  return new Promise((resolve, reject) => {
    const sql = 'UPDATE tblbrands SET name = ? WHERE id = ?';
    pool.query(sql, [name, id], (err, results) => {
      if (err) {
        console.error('Error updating brand:', err);
        reject(err);
      } else {
        if (results.affectedRows > 0) {
          resolve({ message: 'Brand updated successfully' });
        } else {
          reject({ error: 'Failed to update brand' });
        }
      }
    });
  });
};

const deleteBrand = (id) => {
  return new Promise((resolve, reject) => {
    const sql = 'DELETE FROM tblbrands WHERE id = ?';
    pool.query(sql, [id], (err, results) => {
      if (err) {
        console.error('Error deleting brand:', err);
        reject(err);
      } else {
        if (results.affectedRows > 0) {
          resolve({ message: 'Brand deleted successfully' });
        } else {
          reject({ error: 'Failed to delete brand' });
        }
      }
    });
  });
};

module.exports = {
  createBrand ,
  getBrandById,
  getAllBrands,
  updateBrand,
  deleteBrand,
};
