<?php
//require_once('classes/session.php');
require_once('config/classes/htmlclass.php');
require_once('components/pages/customer.php');
require_once('components/pages/brand.php');
require_once('components/pages/addbrand.php');
require_once('components/pages/addvehicle.php');
require_once('components/pages/vehicle.php');
require_once('components/pages/booking.php');



?>
