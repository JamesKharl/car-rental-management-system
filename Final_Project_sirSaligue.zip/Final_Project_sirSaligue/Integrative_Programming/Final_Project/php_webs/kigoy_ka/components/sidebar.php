<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">
  <div class="layout-container">
    <!-- Menu -->

    <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
      <div><br>
        <div class="app-brand demo">
          <a href="index.php" class="app-brand-link">
            <span class="app-brand-logo">
              <img src="assets/img/favicon/icons8-car-rent-48.png" height="90px" width="85px" style="border-radius: 50%;">
            </span>
            <span class="app-brand-text menu-text fw-bolder ms-2">CAR RENTAL <br>MANAGEMENT <br>SYSTEM</span>
          </a>
          <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
          </a>
        </div>
        <br>
        <div class="menu-inner-shadow"></div>

        <ul class="menu-inner py-1">
          <!-- Dashboard -->
          <li class="menu-item <?php if (isset($current_tab) && $current_tab == 'customer') {
                                  echo 'active';
                                } ?> ">
            <a href="home.php?tab=customer" class="menu-link">
              <i class="menu-icon tf-icons bx bxs-home-circle"></i>
              <div data-i18n="Analytics">Customer</div>
            </a>
          </li>


          <li class="menu-item <?php if (isset($current_tab) && $current_tab == 'child' || $current_tab == 'manage_child') {
                                  echo 'active open';
                                } ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
              <i class="menu-icon tf-icons bx bxs-group"></i>
              <div data-i18n="Account Settings">Brands</div>
            </a>
            <ul class="menu-sub">
              <li class="menu-item <?php if (isset($current_tab) && $current_tab == 'brand') {
                                      echo 'active';
                                    } ?>">
                <a href="home.php?tab=addbrand" class="menu-link">
                  <div data-i18n="Account">Add Brands</div>
                </a>
              </li>
              <li class="menu-item <?php if (isset($current_tab) && $current_tab == 'manage_children') {
                                      echo 'active ';
                                    } ?> ">
                <a href="home.php?tab=brand" class="menu-link">
                  <div data-i18n="Notification">Manage Brands</div>
                </a>
              </li>

            </ul>
          </li>

          <li class="menu-item <?php if (isset($current_tab) && $current_tab == 'vehicle' || $current_tab == 'manage_child') {
                                  echo 'active open';
                                } ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
              <i class="menu-icon tf-icons bx bxs-group"></i>
              <div data-i18n="Account Settings">Vehicle</div>
            </a>
            <ul class="menu-sub">
              <li class="menu-item <?php if (isset($current_tab) && $current_tab == 'vehicle') {
                                      echo 'active';
                                    } ?>">
                <a href="home.php?tab=addvehicle" class="menu-link">
                  <div data-i18n="Account">Add Vehicle</div>
                </a>
              </li>
              <li class="menu-item <?php if (isset($current_tab) && $current_tab == 'manage_children') {
                                      echo 'active ';
                                    } ?> ">
                <a href="home.php?tab=vehiclemanage" class="menu-link">
                  <div data-i18n="Notification">Manage Vehicle</div>
                </a>
              </li>

            </ul>
          </li>
          

          <li class="menu-item <?php if (isset($current_tab) && $current_tab == 'booking' || $current_tab == 'manage_vaccine') {
                                  echo 'active open';
                                } ?>">
            <a href="home.php?tab=booking" class="menu-link ">
              <i class="menu-icon tf-icons bx bxs-bong"></i>
              <div data-i18n="Account Settings">Booking</div>
            </a>
          </li>

          <li class="menu-item ">
            <a href="#" class="menu-link" onclick="confirmLogout()">
              <i class="bx bx-power-off me-2"></i>
              <span class="align-middle">Log Out</span>
            </a>
          </li>
        </ul>
      </div>
    </aside>
    <script>
      function confirmLogout() {
        if (confirm("Are you sure you want to log out?")) {
          window.location.href = "config/classes/logout.php";
        }
      }
    </script>
    <!-- / Menu -->