<?php 
function vehicle() { ?>
<div class="container-xxl flex-grow-1 container-p-y">
  <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Vehicles /</span> All Vehicles</h4>
  <div class="row">
    <div class="col-md-12">
      <div class="card mb-4">
        <hr class="my-0" />
        <div class="card-body">
          <div class="app-brand justify-content-center">
            <a href="index.html" class="app-brand-link gap-2">
              <h2><span class="fw-bold py-3 mb-4">Vehicles</span></h2>
            </a>
          </div>
          <h5 class="card-title">All Vehicles</h5>
      <div class="table-responsive">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Brand ID</th>
              <th>Details</th>
              <th>Price</th>
              <th>Fuel Type</th>
              <th>Model</th>
              <th>Year</th>
              <th>Seating Capacity</th>
              <th>Creation Date</th>
            </tr>
          </thead>
          <tbody id="vehicleContainer">
            <!-- Vehicle details will be appended here -->
          </tbody>
        </table>
      </div>
          <br>
        </div>
      </div>
    </div>
  </div>

  <!-- Create Vehicle Modal -->
  <div class="modal fade" id="createVehicleModal" tabindex="-1" aria-labelledby="createVehicleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="createVehicleModalLabel">Create Vehicle</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="createVehicleForm">
            <div class="mb-3">
              <label for="vehicleName" class="form-label">Vehicle Name</label>
              <input type="text" class="form-control" id="vehicleName" name="vehicleName" required>
            </div>
            <!-- Add other vehicle fields here -->
            <button type="button" class="btn btn-primary" onclick="createVehicle()">Create Vehicle</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  function showMessageBox() {
    alert("Save Successfully");
  }

  function showCreateVehicleModal() {
    $('#createVehicleModal').modal('show');
  }

  async function createVehicle() {
    const vehicleName = document.getElementById('vehicleName').value;
    // Include other vehicle data if needed
    const data = {
      vehicleName: vehicleName
      // Add other vehicle data fields here
    };
    const apiUrl = "http://localhost:3000/api/vehicle";
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      if (response.ok) {
        alert('Vehicle created successfully!');
        $('#createVehicleModal').modal('hide');
        // Optionally reload the vehicles list after creation
        loadVehicles();
      } else {
        const errorData = await response.json();
        alert(`Failed to create vehicle: ${errorData.error}`);
      }
    } catch (error) {
      console.error('An error occurred:', error);
      alert('An error occurred while creating vehicle: ' + error.message);
    }
  }

  async function loadVehicles() {
    const apiUrl = "http://localhost:3000/api/vehicle";
    try {
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error(`Failed to retrieve data from the API. Status code: ${response.status}`);
      }
      const vehicles = await response.json();
      const vehicleContainer = document.getElementById('vehicleContainer');
      vehicleContainer.innerHTML = ''; // Clear previous entries
      vehicles.forEach(vehicle => {
        const vehicleRow = document.createElement('tr');
        const creationDate = new Date(vehicle.reg_date);
        const formattedDate = creationDate.toISOString().split('T')[0]; // Extract date part only
        vehicleRow.innerHTML = `
          <td>${vehicle.id}</td>
          <td>${vehicle.name}</td>
          <td>${vehicle.brand_id}</td>
          <td>${vehicle.details}</td>
          <td>${vehicle.price}</td>
          <td>${vehicle.fuel_type}</td>
          <td>${vehicle.model}</td>
          <td>${vehicle.year}</td>
          <td>${vehicle.seating_capacity}</td>
          <td>${formattedDate}</td> <!-- Display date only -->
        `;
        vehicleContainer.appendChild(vehicleRow);
      });
    } catch (error) {
      console.error('An error occurred:', error);
      alert('An error occurred while loading vehicles: ' + error.message);
    }
  }

  document.addEventListener('DOMContentLoaded', loadVehicles);
</script>
<?php } ?>
