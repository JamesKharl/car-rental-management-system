<?php 
function booking() { ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Booking System</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container-xxl flex-grow-1 container-p-y">
  <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Bookings /</span> All Bookings</h4>
  <div class="row">
    <div class="col-md-12">
      <div class="card mb-4">
        <hr class="my-0" />
        <div class="card-body">
          <div class="app-brand justify-content-center">
            <a href="index.html" class="app-brand-link gap-2">
              <h2><span class="fw-bold py-3 mb-4">Bookings</span></h2>
            </a>
          </div>
          <h5 class="card-title">All Bookings</h5>
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>Accept</th>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Vehicle ID</th>
                  <th>Address</th>
                  <th>Phone Number</th>
                  <th>Cash</th>
                  <th>From Date</th>
                  <th>To Date</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody id="bookingContainer">
                <!-- Booking details will be appended here -->
              </tbody>
            </table>
          </div>
          <br>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="bookingModal" tabindex="-1" aria-labelledby="bookingModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="bookingModalLabel">Booking Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div>
          <label for="TbxName" class="form-label">Name:</label>
          <input type="text" id="TbxName" class="form-control" readonly>
        </div>
        <!-- Add more fields for displaying other booking details -->
        <!-- Example: Address, Phone Number, From Date, To Date, etc. -->
        <hr>
        <div>
          <label for="lblId" class="form-label">Vehicle ID:</label>
          <span id="lblId"></span>
        </div>
        <!-- Add more fields for displaying vehicle details -->
        <!-- Example: Vehicle Name, Brand, Price, etc. -->
        <hr>
        <div>
          <label for="cashInput" class="form-label">Enter Cash:</label>
          <input type="number" id="cashInput" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="bookBtn">Book</button>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
<script>
  async function loadBookings() {
    const apiUrl = "http://localhost:3000/api/booking";
    try {
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error(`Failed to retrieve data from the API. Status code: ${response.status}`);
      }
      const bookings = await response.json();
      const bookingContainer = document.getElementById('bookingContainer');
      bookingContainer.innerHTML = ''; // Clear previous entries
      bookings.forEach(booking => {
        const bookingRow = document.createElement('tr');
        const fromDate = new Date(booking.FromDate);
        const toDate = new Date(booking.ToDate);
        const formattedFromDate = fromDate.toISOString().split('T')[0]; // Extract date part only
        const formattedToDate = toDate.toISOString().split('T')[0]; // Extract date part only
        bookingRow.innerHTML = `
          <td><button class="btn btn-primary accept-btn" data-booking-id="${booking.id}" data-bs-toggle="modal" data-bs-target="#bookingModal">Accept</button></td>
          <td>${booking.id}</td>
          <td>${booking.name}</td>
          <td>${booking.VehicleId}</td>
          <td>${booking.address}</td>
          <td>${booking.phone_num}</td>
          <td>${booking.cash}</td>
          <td>${formattedFromDate}</td>
          <td>${formattedToDate}</td>
          <td>${booking.Status}</td>
        `;
        bookingContainer.appendChild(bookingRow);
      });

      // Add event listener to accept buttons
      document.querySelectorAll('.accept-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          const bookingId = btn.getAttribute('data-booking-id');
          try {
            const bookingUrl = `http://localhost:3000/api/booking/${bookingId}`;
            const bookingResponse = await fetch(bookingUrl);
            if (!bookingResponse.ok) {
              throw new Error(`Failed to fetch booking details. Status: ${bookingResponse.status}`);
            }
            const booking = await bookingResponse.json();

            const vehicleUrl = `http://localhost:3000/api/vehicle/${booking.VehicleId}`;
            const vehicleResponse = await fetch(vehicleUrl);
            if (!vehicleResponse.ok) {
              throw new Error(`Failed to fetch vehicle details. Status: ${vehicleResponse.status}`);
            }
            const vehicle = await vehicleResponse.json();

            // Update modal with booking and vehicle details
            document.getElementById('TbxName').value = booking.name;
            document.getElementById('lblId').textContent = vehicle.id;
            // Add more fields and update modal accordingly

            // Add event listener to book button
            document.getElementById('bookBtn').addEventListener('click', async () => {
              const cashInput = document.getElementById('cashInput').value;
              if (cashInput < vehicle.price) {
                alert("Cash is less than the price. Cannot book.");
              } else {
                // Update booking status to 1
                booking.Status = 1;
                try {
                  await updateBooking(bookingId, booking);
                  alert("Booking updated successfully.");
                 
                  // Reload bookings after successful update
                  loadBookings();
                } catch (error) {
                  console.error('An error occurred while updating booking:', error);
                  alert('An error occurred while updating booking.');
                }
              }
            });

          } catch (error) {
            console.error('An error occurred while fetching data:', error);
            alert('An error occurred while fetching data.');
          }
        });
      });

    } catch (error) {
      console.error('An error occurred:', error);
      alert('An error occurred while loading bookings: ' + error.message);
    }
  }

  document.addEventListener('DOMContentLoaded', loadBookings);

  const updateBooking = async (bookingId, booking) => {
    try {
      const response = await fetch(`http://localhost:3000/api/booking/${bookingId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(booking)
      });
      if (!response.ok) {
        throw new Error(`Failed to update booking. Status: ${response.status}`);
      }
    } catch (error) {
      throw new Error(error.message);
    }
  };
</script>

</body>
</html>
<?php } ?>
