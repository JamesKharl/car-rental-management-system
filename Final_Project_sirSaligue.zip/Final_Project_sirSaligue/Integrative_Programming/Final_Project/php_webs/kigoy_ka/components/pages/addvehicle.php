<?php
function addvehicle() { ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Vehicles /</span> Add Vehicle</h4>
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <hr class="my-0" />
                    <div class="card-body">
                        <div class="app-brand justify-content-center">
                            <a href="index.html" class="app-brand-link gap-2">
                                <h2><span class="fw-bold py-3 mb-4">Vehicles</span></h2>
                            </a>
                        </div>
                        <h5 class="card-title">Add a New Vehicle</h5>
                        <br>
                        <form id="createVehicleForm" onsubmit="event.preventDefault(); createVehicle();">
                            <div class="mb-3">
                                <label for="vehicleName" class="form-label">Name</label>
                                <input type="text" class="form-control" id="vehicleName" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="brandSelect" class="form-label">Brand</label>
                                <select class="form-control" id="brandSelect" name="brand_id" required>
                                    <!-- Options will be populated dynamically -->
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="pricePerDay" class="form-label">Price Per Day</label>
                                <input type="text" class="form-control" id="pricePerDay" name="price_per_day" required>
                            </div>
                            <div class="mb-3">
                                <label for="fuelType" class="form-label">Fuel Type</label>
                                <select class="form-control" id="fuelType" name="fuel_type" required>
                                    <option value="">Select Fuel Type</option>
                                    <option value="Regular">Regular</option>
                                    <option value="Special">Special</option>
                                    <option value="Unleaded">Unleaded</option>
                                    <option value="Blue">Blue</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="modelYear" class="form-label">Model Year</label>
                                <input type="text" class="form-control" id="modelYear" name="model_year" required>
                            </div>
                            <div class="mb-3">
                                <label for="seatingCapacity" class="form-label">Seating Capacity</label>
                                <input type="text" class="form-control" id="seatingCapacity" name="seating_capacity" required>
                            </div>
                            <div class="mb-3">
                                <label for="registeredDate" class="form-label">Registered Date</label>
                                <input type="date" class="form-control" id="registeredDate" name="registered_date" required>
                            </div>
                            <div class="mb-3">
                                <label for="imageUrl" class="form-label">Image URL</label>
                                <!-- Change input type to file -->
                                <input type="file" class="form-control" id="image" name="image_url" required>
                            </div>
                            <div class="mb-3">
                                <label for="details" class="form-label">Details</label>
                                <textarea class="form-control" id="details" name="details" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Create Vehicle</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function fetchBrands() {
            const apiUrl = "http://localhost:3000/api/brands";
            try {
                const response = await fetch(apiUrl);
                if (!response.ok) {
                    throw new Error(`Failed to retrieve brands. Status code: ${response.status}`);
                }
                const brands = await response.json();
                const brandSelect = document.getElementById('brandSelect');
                brands.forEach(brand => {
                    const option = document.createElement('option');
                    option.value = brand.id;
                    option.textContent = brand.name;
                    brandSelect.appendChild(option);
                });
            } catch (error) {
                console.error('An error occurred:', error);
                alert('An error occurred while loading brands: ' + error.message);
            }
        }

        async function createVehicle() {
            const name = document.getElementById('vehicleName').value;
            const brand_id = document.getElementById('brandSelect').value;
            const pricePerDay = document.getElementById('pricePerDay').value;
            const fuelType = document.getElementById('fuelType').value;
            const modelYear = document.getElementById('modelYear').value;
            const seatingCapacity = document.getElementById('seatingCapacity').value;
            const registeredDate = document.getElementById('registeredDate').value;
            // Get file input element
            const imageInput = document.getElementById('image');
            // Get the file object from input
            const imageFile = imageInput.files[0];
            const details = document.getElementById('details').value;

            const formData = new FormData();
            formData.append('name', name);
            formData.append('brand_id', brand_id);
            formData.append('price', pricePerDay);
            formData.append('fuel_type', fuelType);
            formData.append('model_year', modelYear);
            formData.append('seating_capacity', seatingCapacity);
            formData.append('reg_date', registeredDate);
            formData.append('image', imageFile);
            formData.append('details', details);

            const apiUrl = "http://localhost:3000/api/vehicle";
            try {
                const response = await fetch(apiUrl, {
                    method: 'POST',
                    body: formData
                });

                if (response.ok) {
                    alert('Vehicle created successfully!');
                    document.getElementById('createVehicleForm').reset();
                } else {
                    const errorData = await response.json();
                    alert(`Failed to create vehicle: ${errorData.error}`);
                }
            } catch (error) {
                console.error('An error occurred:', error);
                alert('An error occurred while creating vehicle: ' + error.message);
            }
        }

        document.addEventListener('DOMContentLoaded', fetchBrands);
    </script>
<?php } ?>
