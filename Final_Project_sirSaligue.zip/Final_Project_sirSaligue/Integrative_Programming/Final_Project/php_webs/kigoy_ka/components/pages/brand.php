<?php 
function brand() { ?>
<div class="container-xxl flex-grow-1 container-p-y">
  <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Brands /</span> All Brands</h4>
  <div class="row">
    <div class="col-md-12">
      <div class="card mb-4">
        <hr class="my-0" />
        <div class="card-body">
          <div class="app-brand justify-content-center">
            <a href="index.html" class="app-brand-link gap-2">
              <h2><span class="fw-bold py-3 mb-4">Brands</span></h2>
            </a>
          </div>
          <h5 class="card-title">All Brands</h5>
      <div class="table-responsive">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Creation Date</th>
            </tr>
          </thead>
          <tbody id="brandContainer">
            <!-- Brand details will be appended here -->
          </tbody>
        </table>
      </div>
          <br>
        </div>
      </div>
    </div>
  </div>

  <!-- Create Brand Modal -->
  <div class="modal fade" id="createBrandModal" tabindex="-1" aria-labelledby="createBrandModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="createBrandModalLabel">Create Brand</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="createBrandForm">
            <div class="mb-3">
              <label for="brandName" class="form-label">Brand Name</label>
              <input type="text" class="form-control" id="brandName" name="brandName" required>
            </div>
            <!-- Add other brand fields here -->
            <button type="button" class="btn btn-primary" onclick="createBrand()">Create Brand</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  function showMessageBox() {
    alert("Save Successfully");
  }

  function showCreateBrandModal() {
    $('#createBrandModal').modal('show');
  }

  async function createBrand() {
    const brandName = document.getElementById('brandName').value;
    // Include other brand data if needed
    const data = {
      brandName: brandName
      // Add other brand data fields here
    };
    const apiUrl = "http://localhost:3000/api/brands";
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      if (response.ok) {
        alert('Brand created successfully!');
        $('#createBrandModal').modal('hide');
        // Optionally reload the brands list after creation
        loadBrands();
      } else {
        const errorData = await response.json();
        alert(`Failed to create brand: ${errorData.error}`);
      }
    } catch (error) {
      console.error('An error occurred:', error);
      alert('An error occurred while creating brand: ' + error.message);
    }
  }

  async function loadBrands() {
    const apiUrl = "http://localhost:3000/api/brands";
    try {
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error(`Failed to retrieve data from the API. Status code: ${response.status}`);
      }
      const brands = await response.json();
      const brandContainer = document.getElementById('brandContainer');
      brandContainer.innerHTML = ''; // Clear previous entries
      brands.forEach(brand => {
        const brandRow = document.createElement('tr');
        const creationDate = new Date(brand.creation_date);
        const formattedDate = creationDate.toISOString().split('T')[0]; // Extract date part only
        brandRow.innerHTML = `
          <td>${brand.id}</td>
          <td>${brand.name}</td>
          <td>${formattedDate}</td> <!-- Display date only -->
        `;
        brandContainer.appendChild(brandRow);
      });
    } catch (error) {
      console.error('An error occurred:', error);
      alert('An error occurred while loading brands: ' + error.message);
    }
  }

  document.addEventListener('DOMContentLoaded', loadBrands);
</script>
<?php } ?>
