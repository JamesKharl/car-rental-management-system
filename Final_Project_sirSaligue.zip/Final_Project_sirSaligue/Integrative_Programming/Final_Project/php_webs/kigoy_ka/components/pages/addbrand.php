<?php 
function addbrand() { ?>
<div class="container-xxl flex-grow-1 container-p-y">
  <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Brands /</span> Add Brand</h4>
  <div class="row">
    <div class="col-md-12">
      <div class="card mb-4">
        <hr class="my-0" />
        <div class="card-body">
          <div class="app-brand justify-content-center">
            <a href="index.html" class="app-brand-link gap-2">
              <h2><span class="fw-bold py-3 mb-4">Brands</span></h2>
            </a>
          </div>
          <h5 class="card-title">Add a New Brand</h5>
          <br>
          <form id="createBrandForm" onsubmit="event.preventDefault(); createBrand();">
            <div class="mb-3">
              <label for="brandName" class="form-label">Brand Name</label>
              <input type="text" class="form-control" id="brandName" name="brandName" required>
            </div>
            <div class="mb-3">
              <label for="creationDate" class="form-label">Creation Date</label>
              <input type="date" class="form-control" id="creationDate" name="creationDate" required>
            </div>
            <button type="submit" class="btn btn-primary">Create Brand</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  async function createBrand() {
    const brandName = document.getElementById('brandName').value;
    const creationDate = document.getElementById('creationDate').value;

    const data = {
      name: brandName,
      creation_date: creationDate
    };

    const apiUrl = "http://localhost:3000/api/brands";
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });

      if (response.ok) {
        alert('Brand created successfully!');
        document.getElementById('createBrandForm').reset();
      } else {
        const errorData = await response.json();
        alert(`Failed to create brand: ${errorData.error}`);
      }
    } catch (error) {
      console.error('An error occurred:', error);
      alert('An error occurred while creating brand: ' + error.message);
    }
  }
</script>
<?php } ?>
