<?php 
function customer() { ?>
<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">
    <div class="col-md-12">
      <div class="card mb-4">
        <hr class="my-0" />
      </div>
      <div class="card mb-4">
        <hr class="my-0" />
        <div class="card-body">
          <div class="app-brand justify-content-center">
            <h2><span class="fw-bold py-3 mb-4">Vehicles</span></h2>
          </div>
          <br>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Vehicle Name</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody id="vehicleContainer"></tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="bookModal" tabindex="-1" aria-labelledby="bookModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="bookModalLabel">Book Vehicle</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="bookVehicleForm">
            <input type="hidden" id="vehicle_id" name="vehicle_id">
            <div class="mb-3">
              <label for="name" class="form-label">Name</label>
              <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
              <label for="address" class="form-label">Address</label>
              <input type="text" class="form-control" id="address" name="address" required>
            </div>
            <div class="mb-3">
              <label for="contact_no" class="form-label">Contact No</label>
              <input type="text" class="form-control" id="contact_no" name="contact_no" required>
            </div>
            <div class="mb-3">
              <label for="from_date" class="form-label">From Date</label>
              <input type="date" class="form-control" id="from_date" name="from_date" required>
            </div>
            <div class="mb-3">
              <label for="to_date" class="form-label">To Date</label>
              <input type="date" class="form-control" id="to_date" name="to_date" required>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary" onclick="confirmBooking()">Confirm Booking</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script>
    async function loadVehicles() {
      const apiUrl = "http://localhost:3000/api/vehicle";
      try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
          throw new Error(`Failed to retrieve data from the API. Status code: ${response.status}`);
        }
        const vehicles = await response.json();
        const vehicleContainer = document.getElementById('vehicleContainer');
        vehicles.forEach(vehicle => {
          const vehicleRow = document.createElement('tr');
          vehicleRow.innerHTML = `
            <td>${vehicle.name}</td>
            <td>
              <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#bookModal" onclick="setVehicleId(${vehicle.id}, '${vehicle.name}')">Book</button>
            </td>
          `;
          vehicleContainer.appendChild(vehicleRow);
        });
      } catch (error) {
        console.error('An error occurred:', error);
        alert('An error occurred while loading vehicles: ' + error.message);
      }
    }

    function setVehicleId(vehicleId, vehicleName) {
      document.getElementById('vehicle_id').value = vehicleId;
      document.getElementById('bookModalLabel').innerText = `Book Vehicle: ${vehicleName}`;
    }

    async function confirmBooking() {
      const form = document.getElementById('bookVehicleForm');
      const formData = new FormData(form);
      const data = Object.fromEntries(formData.entries());
      data.VehicleId = data.vehicle_id;
      data.phone_num = data.contact_no;
      data.FromDate = data.from_date;
      data.ToDate = data.to_date;
      data.Status = "Pending"; // Set a default status

      const apiUrl = "http://localhost:3000/api/booking";
      try {
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(data)
        });
        const result = await response.json();
        if (response.ok) {
          alert('Booking created successfully!');
          form.reset();
          const bookModal = new bootstrap.Modal(document.getElementById('bookModal'));
          bookModal.hide();
        } else {
          alert(`Failed to create booking: ${result.error}`);
        }
      } catch (error) {
        console.error('An error occurred:', error);
        alert('An error occurred while creating booking: ' + error.message);
      }
    }

    document.addEventListener('DOMContentLoaded', loadVehicles);
  </script>
</div>
<?php } ?>
