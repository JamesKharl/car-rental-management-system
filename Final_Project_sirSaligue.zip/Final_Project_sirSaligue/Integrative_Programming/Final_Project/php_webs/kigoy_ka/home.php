<?php
   include("config/initialize.php");
  

   HTML :: head();
   $current_tab = " ";

   if(isset($_GET['tab']))
   {
    $current_tab = $_GET['tab'];
   }
   HTML :: sidebar($current_tab);
   HTML :: navbar();


   if($current_tab == "customer")
   {
      customer();
   }
   if($current_tab == "brand")
   {
      brand();
   }
   if($current_tab == "addbrand")
   {
      addbrand();
   }
   if($current_tab == "addvehicle")
   {
      addvehicle();
   }
   if($current_tab == "vehiclemanage")
   {
      vehicle();
   }

   if($current_tab == "booking")
   {
      booking();
   }



   HTML ::footer();

?>
