﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace carrental
{
    public partial class Brands : Form
    {
        public Brands()
        {
            InitializeComponent();
        }

        private void BtnCreateBrands_Click(object sender, EventArgs e)
        {
            AddBrands ab = new AddBrands();
            ab.ShowDialog();  
            this.Hide();

        }

        private void dgvBrands_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int selectedrow;
                selectedrow = e.RowIndex;
                DataGridViewRow row = dgvBrands.Rows[selectedrow];

                // Assigning values from the selected row to corresponding variables
                int id = int.Parse(row.Cells["id"].Value.ToString());
                string name = row.Cells["name"].Value.ToString();
                DateTime date = DateTime.Parse(row.Cells["creationDate"].Value.ToString());

                // Update labels with the values from the selected row
                lblid.Text = id.ToString();
                lblName.Text = name;
                lbldateCreate.Text = date.ToShortDateString();

                Operation.idContent = id;
                Form mainForm = this.FindForm();
                Operation.checker = true;

                Panel pLoad = mainForm.Controls["PLoad"] as Panel;
                if (pLoad != null)
                {
                    pLoad.BackgroundImage = null;
                    pLoad.Controls.Clear();

                    AddBrands ii = new AddBrands();
                    pLoad.Controls.Add(ii);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async Task LoadBrandsAsync()
        {
            string apiUrl = "http://localhost:3000/api/brands";

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonResponse = await response.Content.ReadAsStringAsync();
                        Brand[] brands = JsonConvert.DeserializeObject<Brand[]>(jsonResponse);
                        dgvBrands.DataSource = brands;
                    }
                    else
                    {
                        MessageBox.Show("Failed to retrieve data from the API. Status code: " + response.StatusCode);
                    }
                }
                catch (HttpRequestException ex)
                {
                    MessageBox.Show("An error occurred while sending the request: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private async void Brands_Load(object sender, EventArgs e)
        {
            await LoadBrandsAsync();
        }

        private HttpClient client = new HttpClient();
        private async Task Delete()
        {
            var apiUrl = "http://localhost:3000/api/brands/" + Operation.idContent;  // API endpoint for deleting a brand

            try
            {
                HttpResponseMessage response = await client.DeleteAsync(apiUrl);
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Brand deleted successfully!");

                    Operation.checker = false;
                    Form mainForm = this.FindForm();

                    Panel pLoad = mainForm.Controls["PLoad"] as Panel;
                    if (pLoad != null)
                    {
                        pLoad.BackgroundImage = null;
                        pLoad.Controls.Clear();

                        // Optionally, you may want to refresh the view after deleting the brand
                        Brands vi = new Brands();
                        pLoad.Controls.Add(vi);
                    }
                }
                else
                {
                    string errorMessage = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Failed to delete brand. Status code: {response.StatusCode}\nError message: {errorMessage}");
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred while sending the request: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private async void tbxDelete_Click(object sender, EventArgs e)
        {
            await Delete();
        }
        private async Task Search()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    // Assuming tbxSearch contains the ID to search for
                    string id = tbxSearch.Text.Trim();

                    // Update the URL with the correct endpoint
                    string url;

                    if (string.IsNullOrEmpty(id))
                    {
                        // If tbxSearch is empty, fetch all brands
                        url = $"http://localhost:3000/api/brands/";
                    }
                    else
                    {
                        url = $"http://localhost:3000/api/brands/{id}";
                    }

                    HttpResponseMessage response = await client.GetAsync(url);

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonResponse = await response.Content.ReadAsStringAsync();
                        dynamic result = JsonConvert.DeserializeObject(jsonResponse);

                        // Check if the request was successful
                        if (string.IsNullOrEmpty(id))
                        {
                            // If tbxSearch is empty, display all brands
                            dgvBrands.DataSource = JsonConvert.DeserializeObject<List<Brand>>(jsonResponse);
                        }
                        else if (result.success == true)
                        {
                            dynamic brand = result.brand;

                            // Create a new list to hold the search result
                            List<Brand> searchResult = new List<Brand>
                    {
                        new Brand
                        {
                            id = brand.id,
                            name = brand.name,
                            creationdate = brand.creationdate
                        }
                    };

                            // Assign the search result to the DataGridView's DataSource
                            dgvBrands.DataSource = searchResult;
                        }
                        else
                        {
                            dgvBrands.DataSource = null; // Clear the DataGridView if brand is not found
                        }
                    }
                    else
                    {
                        dgvBrands.DataSource = null; // Clear the DataGridView if request fails
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void tbxSearch_TextChanged(object sender, EventArgs e)
        {
            await Search();
        }

    }
}
