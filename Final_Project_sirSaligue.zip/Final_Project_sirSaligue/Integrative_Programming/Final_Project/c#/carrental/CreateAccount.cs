﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace carrental
{
    public partial class CreateAccount : Form
    {
        public CreateAccount()
        {
            InitializeComponent();
        }
        private async Task AddAccount()
        {
            string apiUrl = "http://localhost:3000/api/user/create";  // Updated endpoint for clarity

            using (HttpClient client = new HttpClient())
            {
                // Prepare the payload
                var payload = new
                {
                    username = TxtUsername.Text,
                    password = TxtPassword.Text
                };

                // Serialize our concrete class into a JSON String
                var stringPayload = JsonConvert.SerializeObject(payload);

                // Wrap our JSON inside a StringContent which then can be used by the HttpClient class
                var httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                try
                {
                    // Send POST request
                    HttpResponseMessage response = await client.PostAsync(apiUrl, httpContent);
                    if (response.IsSuccessStatusCode)
                    {
                        // Assuming the response contains the JSON object which includes the details of the user or a success message
                        string responseContent = await response.Content.ReadAsStringAsync();
                        // MessageBox.Show("Login successful");

                        Operation.username = TxtUsername.Text;
                        Operation.password = TxtPassword.Text;                       
                    }
                    else
                    {
                        MessageBox.Show("Account Succesfully Created!");
                    }
                }
                catch (HttpRequestException ex)
                {
                    MessageBox.Show("An error occurred while sending the request: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
        private async void BtnCreateAcc_Click(object sender, EventArgs e)
        {
            await AddAccount(); 
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 fm =new Form1();
            fm.Show();
            this.Hide();
        }
    }
}
