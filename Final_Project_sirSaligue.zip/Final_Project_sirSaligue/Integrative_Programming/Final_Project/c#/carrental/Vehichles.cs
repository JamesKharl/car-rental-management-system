﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Diagnostics;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace carrental
{
    public partial class Vehichles : Form
    {
        public Vehichles()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddVehichle av = new AddVehichle();
            av.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int selectedrow;
                selectedrow = e.RowIndex;
                DataGridViewRow row = dgvVehicle.Rows[selectedrow];

                Operation.idContent = int.Parse(row.Cells[0].Value.ToString());
                Operation.checker = true;

                AddVehichle ii = new AddVehichle();
                ii.Show();
                this.Hide();


            }
            catch (Exception c) { MessageBox.Show(c.Message); }
        }
        private async Task LoadVehicle()
        {
            string apiUrl = "http://localhost:3000/api/vehicle";

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonResponse = await response.Content.ReadAsStringAsync();
                        Vehicle[] brands = JsonConvert.DeserializeObject<Vehicle[]>(jsonResponse);
                        dgvVehicle.DataSource = brands;
                    }
                    else
                    {
                        MessageBox.Show("Failed to retrieve data from the API. Status code: " + response.StatusCode);
                    }
                }
                catch (HttpRequestException ex)
                {
                    MessageBox.Show("An error occurred while sending the request: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
        private async void Vehichles_Load(object sender, EventArgs e)
        {
            await LoadVehicle();
        }
        private async Task Search()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    string id = tbxSearch.Text.Trim();
                    string url = string.IsNullOrEmpty(id) ? "http://localhost:3000/api/vehicle" : $"http://localhost:3000/api/vehicle/{id}";

                    HttpResponseMessage response = await client.GetAsync(url);

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonResponse = await response.Content.ReadAsStringAsync();
                        if (string.IsNullOrEmpty(id))
                        {
                            List<Vehicle> vehicles = JsonConvert.DeserializeObject<List<Vehicle>>(jsonResponse);
                            dgvVehicle.DataSource = vehicles;
                        }
                        else
                        {
                            Vehicle vehicle = JsonConvert.DeserializeObject<Vehicle>(jsonResponse);
                            dgvVehicle.DataSource = new List<Vehicle> { vehicle };
                        }
                    }
                    else
                    {
                        dgvVehicle.DataSource = null; // Clear the DataGridView if request fails
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void tbxSearch_TextChanged(object sender, EventArgs e)
        {
            await Search();
        }
    }
}
        

              
