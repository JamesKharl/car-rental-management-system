﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace carrental
{
    public partial class AddVehichle : Form
    {
        
        public AddVehichle()
        {
            InitializeComponent();
            
        }
       
        DateTime nowTime = DateTime.Now;
        string imagelocator = "";
        private string GetImageDirectory()
        {
            bool isDevelopment = true; // Assume it's development by default, toggle based on your actual environment

            // Define your development path
            string devPath = @"C:\sir_saligue\Final_Project_sirSaligue\Integrative_Programming\Final_Project\c#\carrental\image";

            // Get the base directory for the application, typically used in production
            string prodPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images");

            if (isDevelopment)
            {
                Directory.CreateDirectory(devPath);
                return devPath;
            }
            else
            {
                Directory.CreateDirectory(prodPath);
                return prodPath;
            }
        }
        private Image ResizeImage(Image image, int width, int height)
        {
            var destRect = new Rectangle(0, 0, width, height);
            var destImage = new Bitmap(width, height);

            destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);

            using (var graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
                graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;

                using (var wrapMode = new System.Drawing.Imaging.ImageAttributes())
                {
                    wrapMode.SetWrapMode(System.Drawing.Drawing2D.WrapMode.TileFlipXY);
                    graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }

            return destImage;
        }
        private void btnAddImage_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog fileOpen = new OpenFileDialog())
            {
                fileOpen.Title = "Open Image File";
                fileOpen.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp; *.png)|*.jpg; *.jpeg; *.gif; *.bmp; *.png";
                if (fileOpen.ShowDialog() == DialogResult.OK)
                {
                    // Load the image with proper memory management
                    using (Image originalImage = Image.FromFile(fileOpen.FileName))
                    {
                        // Optional: Resize the image to a more manageable size if necessary
                        Image resizedImage = ResizeImage(originalImage, pbxVehicle.Width, pbxVehicle.Height);

                        // Set the picture box image
                        pbxVehicle.Image = resizedImage;

                        string targetDirectory = GetImageDirectory();
                        string fileName = Path.GetFileName(fileOpen.FileName);
                        string destinationFilePath = Path.Combine(targetDirectory, fileName);

                        // Copy the image to the local application's directory
                        File.Copy(fileOpen.FileName, destinationFilePath, true);

                        // Save only the relative path in imagelocator
                        imagelocator = Path.Combine("Image", fileName);
                    }
                }
            }
        }
        private HttpClient client = new HttpClient();      

        private async Task<int?> GetSelectedBrandId()
        {
            if (cbxBrands.SelectedItem == null)
            {
                MessageBox.Show("No brand selected.");
                return null;
            }

            if (!(cbxBrands.SelectedItem is Brand selectedBrand))
            {
                MessageBox.Show("Selected item is not a brand.");
                return null;
            }

            int selectedBrandId = selectedBrand.id;
            return selectedBrandId;
        }

        private async Task AddVehicle()
        {
            var apiUrl = "http://localhost:3000/api/vehicle";  // API endpoint for adding vehicles

            int? selectedBrandId = await GetSelectedBrandId();
            if (!selectedBrandId.HasValue)
            {
                MessageBox.Show("Please select a brand.");
                return;
            }

            try
            {
                var vehicle = new
                {
                    name = tbxName.Text,
                    brand_id = selectedBrandId.Value,
                    details = tbxDetails.Text,
                    price = int.Parse(tbxPerDay.Text),
                    fuel_type = cbxFuelType.Text,
                    model_year = int.Parse(tbxModelYear.Text),
                    seating_capacity = int.Parse(tbxSeatingCap.Text),
                    image = imagelocator,
                    reg_date = dtpDate.Value.ToString("yyyy-MM-dd")
                };

                var json = JsonConvert.SerializeObject(vehicle);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(apiUrl, content);
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Vehicle added successfully!");
                    tbxName.Clear();
                    tbxDetails.Clear();
                    tbxPerDay.Clear();
                    tbxModelYear.Clear();
                    tbxSeatingCap.Clear();
                    pbxVehicle.Image = null; // Clear the PictureBox
                    pbxVehicle.Tag = null; // Clear the PictureBox's Tag property
                    dtpDate.ResetText(); 
                }
                else
                {
                    MessageBox.Show($"Failed to add vehicle. Status code: {response.StatusCode}");
                }
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Invalid input format: " + ex.Message);
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred while sending the request: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private async void btnAdd_Click(object sender, EventArgs e)
        {
            await AddVehicle();
        }
        private async Task LoadBrands()
        {
            try
            {
                // Assuming your API is hosted locally at http://localhost:3000
                var apiClient = new ApiClient("http://localhost:3000");
                List<Brand> brands = await apiClient.GetAllBrandsAsync();

                // Clear existing items in the ComboBox
                cbxBrands.Items.Clear();

                // Add fetched brands to the ComboBox
                foreach (var brand in brands)
                {
                    cbxBrands.Items.Add(brand);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading brands: " + ex.Message);
            }
        }
        private async void AddVehichle_Load(object sender, EventArgs e)
        {
            await LoadBrands();
            if (Operation.checker == true)
            {
                await checkID(Operation.idContent);
                btnUpdate.Visible = true;
                btnAdd.Visible = false;
                btnDelete.Visible = true;
                Operation.checker = false;
            }
            else
            {
                btnUpdate.Visible = false;
                btnAdd.Visible = true;
                btnDelete.Visible = false;
            }
        }
        private async Task UpdateVehicle()
        {
            var apiUrl = "http://localhost:3000/api/vehicle/" + Operation.idContent;   

            int? selectedBrandId = await GetSelectedBrandId();
            if (!selectedBrandId.HasValue)
            {
                MessageBox.Show("Please select a brand.");
                return;
            }

            try
            {
                var vehicle = new
                {
                    name = tbxName.Text,
                    brand_id = selectedBrandId.Value,
                    details = tbxDetails.Text,
                    price = int.Parse(tbxPerDay.Text),
                    fuel_type = cbxFuelType.Text,
                    model_year = int.Parse(tbxModelYear.Text),
                    seating_capacity = int.Parse(tbxSeatingCap.Text),
                    image = imagelocator,
                    updation_date = DateTime.Now.ToString("yyyy-MM-dd")
                };

                var json = JsonConvert.SerializeObject(vehicle);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PutAsync(apiUrl, content);
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Vehicle updated successfully!");
                }
                else
                {
                    MessageBox.Show($"Failed to update vehicle. Status code: {response.StatusCode}");
                }
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Invalid input format: " + ex.Message);
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred while sending the request: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private async Task checkID(int vehicleId)
        {
            var apiUrl = $"http://localhost:3000/api/vehicle/{vehicleId}";
            using (var client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        var jsonString = await response.Content.ReadAsStringAsync();
                        var vehicle = JsonConvert.DeserializeObject<VehicleId>(jsonString);

                        string brandName = await GetBrandNameById(vehicle.brand_id);

                        lblId.Text = vehicle.id.ToString();
                        tbxName.Text = vehicle.name;
                        cbxBrands.Text = brandName;
                        tbxPerDay.Text = vehicle.price.ToString();
                        tbxDetails.Text = vehicle.details;
                        cbxFuelType.Text = vehicle.fuel_type;
                        tbxModelYear.Text = vehicle.model_year.ToString();
                        tbxSeatingCap.Text = vehicle.seating_capacity.ToString();
                        if (DateTime.TryParse(vehicle.regDate, out DateTime parsedDate))
                        {
                            dtpDate.Text = parsedDate.ToShortDateString();
                        }
                        else
                        {
                            dtpDate.Text = "Invalid Date";
                        }

                        pbxVehicle.BackgroundImage = null;
                        string basePath = AppDomain.CurrentDomain.BaseDirectory;
                        string projectRoot = Directory.GetParent(basePath).Parent.Parent.FullName;
                        string imagePath = Path.Combine(projectRoot, vehicle.image);

                        if (File.Exists(imagePath))
                        {
                            pbxVehicle.Image = Image.FromFile(imagePath);
                        }
                        else
                        {
                            MessageBox.Show("Image file not found: " + imagePath);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Failed to retrieve product. Status code: " + response.StatusCode);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving product: " + ex.Message);
                }
            }
        }
        private async Task<string> GetBrandNameById(int brandId)
        {
            try
            {
                ApiClient client = new ApiClient("http://localhost:3000");
                List<Brand> brands = await client.GetAllBrandsAsync();
                Brand brand = brands.FirstOrDefault(b => b.id == brandId);
                if (brand != null)
                {
                    return brand.name;
                }
                else
                {
                    return "Brand not found";
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
        }
        private async Task DeleteVehicle()
        {
            try
            {
                var apiUrl = "http://localhost:3000/api/vehicle/" + Operation.idContent;  // API endpoint for deleting a vehicle

                HttpResponseMessage response = await client.DeleteAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Vehicle deleted successfully!");

                    Operation.checker = false;
                    Form mainForm = this.FindForm();

                    Panel pLoad = mainForm.Controls["PLoad"] as Panel;
                    if (pLoad != null)
                    {
                        pLoad.BackgroundImage = null;
                        pLoad.Controls.Clear();

                        // Optionally, you may want to refresh the view after deleting the vehicle
                        Vehichles vh = new Vehichles();
                        pLoad.Controls.Add(vh);
                    }
                }
                else
                {
                    string errorMessage = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Failed to delete vehicle. Status code: {response.StatusCode}\nError message: {errorMessage}");
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred while sending the request: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                // It's good practice to dispose of HttpResponseMessage to release resources
                client.Dispose();
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            await DeleteVehicle();
        }

        private async void btnUpdate_Click_1(object sender, EventArgs e)
        {
            await UpdateVehicle();
        }
    }
}
