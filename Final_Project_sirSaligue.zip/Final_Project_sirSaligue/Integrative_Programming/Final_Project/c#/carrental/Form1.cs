﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace carrental
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void BtnLogin_Click(object sender, EventArgs e)
        {
            await checkUser();
        }
        private async Task checkUser()
        {
            string apiUrl = "http://localhost:3000/api/user/login";  // Updated endpoint for clarity

            using (HttpClient client = new HttpClient())
            {
                // Prepare the payload
                var payload = new
                {
                    username = tbxUsername.Text,
                    password = tbxPassword.Text
                };

                // Serialize our concrete class into a JSON String
                var stringPayload = JsonConvert.SerializeObject(payload);

                // Wrap our JSON inside a StringContent which then can be used by the HttpClient class
                var httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                try
                {
                    // Send POST request
                    HttpResponseMessage response = await client.PostAsync(apiUrl, httpContent);
                    if (response.IsSuccessStatusCode)
                    {
                        // Assuming the response contains the JSON object which includes the details of the user or a success message
                        string responseContent = await response.Content.ReadAsStringAsync();
                        // MessageBox.Show("Login successful");

                        Operation.username = tbxUsername.Text;
                        Operation.password = tbxPassword.Text;
                        MainForm mm = new MainForm();
                        this.Hide();
                        mm.Show();
                    }
                    else
                    {
                        MessageBox.Show("Login failed: Incorrect Username or Password. Please check your credentials and try again.");
                    }
                }
                catch (HttpRequestException ex)
                {
                    MessageBox.Show("An error occurred while sending the request: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            CreateAccount ca=new CreateAccount();
            this.Hide();
            ca.Show();
        }
    }
}
