﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace carrental
{
    public partial class AddBrands : Form
    {
        public AddBrands()
        {
            InitializeComponent();
        }
        
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    
        private HttpClient client = new HttpClient();
        private async Task AddBrand()
        {
            var apiUrl = "http://localhost:3000/api/brands";  // API endpoint for adding products

            var brand = new
            {
                name = tbxName.Text,               
                creation_date = DtpCDate.Value.ToString("yyyy-MM-dd")
            };

            var json = JsonConvert.SerializeObject(brand);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                HttpResponseMessage response = await client.PostAsync(apiUrl, content);
                if (response.IsSuccessStatusCode)
                {
                    // Assume response body just confirms addition, adjust as necessary if the response includes more details
                    MessageBox.Show("Brand added successfully!");

                    tbxName.Clear();                  
                    DtpCDate.ResetText();


                    // Optional: Process response further if needed
                    // string responseContent = await response.Content.ReadAsStringAsync();
                    // YourResponseType data = JsonConvert.DeserializeObject<YourResponseType>(responseContent);
                }
                else
                {
                    MessageBox.Show($"Failed to add brand. Status code: {response.StatusCode}");
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred while sending the request: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private async void BtnCreate_Click(object sender, EventArgs e)
        {
            await AddBrand();
        }

        private void AddBrands_Load(object sender, EventArgs e)
        {

        }
    }
}
