﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static carrental.ApiClient;

namespace carrental
{
    public partial class Customer : Form
    {

        public Customer()

        {
            InitializeComponent();
        }

        private async void dgvVehicle_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0 || e.RowIndex >= dgvVehicle.Rows.Count)
                {
                    return; // Invalid row index, exit method
                }

                DataGridViewRow row = dgvVehicle.Rows[e.RowIndex];
                Operation.idContent = int.Parse(row.Cells[0].Value.ToString());

                await checkID(Operation.idContent);
                gbxview.BringToFront();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async Task checkID(int vehicleId)
        {
            var apiUrl = $"http://localhost:3000/api/vehicle/{vehicleId}";
            using (var client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        var jsonString = await response.Content.ReadAsStringAsync();
                        var vehicle = JsonConvert.DeserializeObject<VehicleId>(jsonString);

                        string brandName = await GetBrandNameById(vehicle.brand_id);

                        lblId.Text = vehicle.id.ToString();
                        lblName1.Text = vehicle.name;
                        lblBrand.Text = brandName;
                        lblPrice.Text = vehicle.price.ToString();
                        tbxDetail.Text = vehicle.details;
                        lblFuel.Text = vehicle.fuel_type;
                        lblYear.Text = vehicle.model_year.ToString();
                        lblSeating.Text = vehicle.seating_capacity.ToString();
                        if (DateTime.TryParse(vehicle.regDate, out DateTime parsedDate))
                        {
                            lblDate1.Text = parsedDate.ToShortDateString();
                        }
                        else
                        {
                            lblDate1.Text = "Invalid Date";
                        }

                        pbxVehicle.BackgroundImage = null;
                        string basePath = AppDomain.CurrentDomain.BaseDirectory;
                        string projectRoot = Directory.GetParent(basePath).Parent.Parent.FullName;
                        string imagePath = Path.Combine(projectRoot, vehicle.image);

                        if (File.Exists(imagePath))
                        {
                            pbxVehicle.Image = Image.FromFile(imagePath);
                        }
                        else
                        {
                            MessageBox.Show("Image file not found: " + imagePath);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Failed to retrieve Vehicle. Status code: " + response.StatusCode);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving product: " + ex.Message);
                }
            }
        }
        private async Task<string> GetBrandNameById(int brandId)
        {
            try
            {
                ApiClient client = new ApiClient("http://localhost:3000");
                List<Brand> brands = await client.GetAllBrandsAsync();
                Brand brand = brands.FirstOrDefault(b => b.id == brandId);
                if (brand != null)
                {
                    return brand.name;
                }
                else
                {
                    return "Brand not found";
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
        }
        private async Task LoadVehicle()
        {
            string apiUrl = "http://localhost:3000/api/vehicle";

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonResponse = await response.Content.ReadAsStringAsync();
                        Vehicle[] brands = JsonConvert.DeserializeObject<Vehicle[]>(jsonResponse);
                        dgvVehicle.DataSource = brands;
                    }
                    else
                    {
                        MessageBox.Show("Failed to retrieve data from the API. Status code: " + response.StatusCode);
                    }
                }
                catch (HttpRequestException ex)
                {
                    MessageBox.Show("An error occurred while sending the request: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
        
        private async void Customer_Load(object sender, EventArgs e)
        {
            await LoadVehicle();
            
        }
        private async Task Search()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    string id = tbxSearch.Text.Trim();
                    string url = string.IsNullOrEmpty(id) ? "http://localhost:3000/api/vehicle" : $"http://localhost:3000/api/vehicle/{id}";

                    HttpResponseMessage response = await client.GetAsync(url);

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonResponse = await response.Content.ReadAsStringAsync();
                        if (string.IsNullOrEmpty(id))
                        {
                            List<Vehicle> vehicles = JsonConvert.DeserializeObject<List<Vehicle>>(jsonResponse);
                            dgvVehicle.DataSource = vehicles;
                        }
                        else
                        {
                            Vehicle vehicle = JsonConvert.DeserializeObject<Vehicle>(jsonResponse);
                            dgvVehicle.DataSource = new List<Vehicle> { vehicle };
                        }
                    }
                    else
                    {
                        dgvVehicle.DataSource = null; // Clear the DataGridView if request fails
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void tbxSearch_TextChanged(object sender, EventArgs e)
        {
            await Search();
        }
        private HttpClient client = new HttpClient();
        private async Task AddBooking()
        {
            var apiUrl = "http://localhost:3000/api/booking";  // API endpoint for adding bookings

            try
            {
                var booking = new
                {
                    name = TbxName.Text,
                    VehicleId = int.Parse(lblId.Text),
                    address = TbxAddress.Text,
                    phone_num = int.Parse(TbxContact.Text),
                    FromDate = dtpFrom.Value.ToString("yyyy-MM-dd"),
                    ToDate = dtpTo.Value.ToString("yyyy-MM-dd"),
                    Status = "Pending" // Example status
                };

                var json = JsonConvert.SerializeObject(booking);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(apiUrl, content);
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Booking successfully added!");
                    TbxName.Clear();
                    TbxAddress.Clear();
                    TbxContact.Clear();
                    dtpFrom.ResetText();
                    dtpTo.ResetText();
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Conflict) // Assuming 409 Conflict for booking conflicts
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    MessageBox.Show("Booking conflict: " + responseContent);
                }
                else
                {
                    MessageBox.Show($"Failed to add booking. Status code: {response.StatusCode}");
                }
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Invalid input format: " + ex.Message);
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred while sending the request: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private async void btnBooking_Click(object sender, EventArgs e)
        {
            await AddBooking();
        }      
    }
}
