﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static carrental.ApiClient;

namespace carrental
{
    public partial class CustomerDetails : Form
    {
        public CustomerDetails()
        {
            InitializeComponent();
        }
        private HttpClient client = new HttpClient();
        private async Task Booked()
        {
            var apiUrl = "http://localhost:3000/api/booking/" + Operation.idContent;

            try
            {
                int cash = int.Parse(tbxCash.Text);
                int price = int.Parse(lblPrice.Text);

                if (cash < price)
                {
                    MessageBox.Show("Insufficient cash. Please provide enough cash to book the vehicle.");
                    return; // Exit the method if cash is insufficient
                }

                var booking = new
                {
                    name = TbxName.Text,
                    VehicleId = int.Parse(lblId.Text),
                    address = TbxAddress.Text,
                    phone_num = int.Parse(TbxContact.Text),
                    FromDate = dtpFrom.Value.ToString("yyyy-MM-dd"),
                    ToDate = dtpTo.Value.ToString("yyyy-MM-dd"),
                    Status = 1, // Example status
                    cash = cash
                };

                var json = JsonConvert.SerializeObject(booking);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (var client = new HttpClient())
                {
                    HttpResponseMessage response = await client.PutAsync(apiUrl, content);
                    if (response.IsSuccessStatusCode)
                    {
                        if (cash == price)
                        {
                            MessageBox.Show("Enjoy your vehicle!");
                        }
                        else if (cash > price)
                        {
                            int change = cash - price;
                            MessageBox.Show($"Enjoy your vehicle! Your change is {change}.");
                        }
                    }
                    else
                    {
                        MessageBox.Show($"Failed to update. Status code: {response.StatusCode}");
                    }
                }
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Invalid input format: " + ex.Message);
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred while sending the request: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private async void btnBooked_Click(object sender, EventArgs e)
        {
            await Booked();
        }
        
        public async Task Delete()
        {
            try
            {
                var apiUrl = "http://localhost:3000/api/booking/" + Operation.idContent;  // API endpoint for deleting a vehicle

                HttpResponseMessage response = await client.DeleteAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Customer deleted successfully!");

                    Operation.checker = false;
                    Form mainForm = this.FindForm();

                    Panel pLoad = mainForm.Controls["PLoad"] as Panel;
                    if (pLoad != null)
                    {
                        pLoad.BackgroundImage = null;
                        pLoad.Controls.Clear();

                        // Optionally, you may want to refresh the view after deleting the vehicle
                        Booking vh = new Booking();
                        pLoad.Controls.Add(vh);
                    }
                }
                else
                {
                    string errorMessage = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Failed to delete customer. Status code: {response.StatusCode}\nError message: {errorMessage}");
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred while sending the request: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                // It's good practice to dispose of HttpResponseMessage to release resources
                client.Dispose();
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            await Delete();
        }
        public async Task CheckID(int bookingId)
        {
            var bookingApiUrl = $"http://localhost:3000/api/booking/{bookingId}";
            using (var client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage bookingResponse = await client.GetAsync(bookingApiUrl);
                    if (bookingResponse.IsSuccessStatusCode)
                    {
                        var bookingJsonString = await bookingResponse.Content.ReadAsStringAsync();
                        var booking = JsonConvert.DeserializeObject<BookingId>(bookingJsonString);

                        var vehicleApiUrl = $"http://localhost:3000/api/vehicle/{booking.VehicleId}";
                        HttpResponseMessage vehicleResponse = await client.GetAsync(vehicleApiUrl);

                        if (vehicleResponse.IsSuccessStatusCode)
                        {
                            var vehicleJsonString = await vehicleResponse.Content.ReadAsStringAsync();
                            var vehicle = JsonConvert.DeserializeObject<VehicleId>(vehicleJsonString);

                            string brandName = await GetBrandNameById(vehicle.brand_id);

                            // Updating the UI
                            TbxName.Invoke(new Action(() => TbxName.Text = booking.name));
                            TbxAddress.Invoke(new Action(() => TbxAddress.Text = booking.address));
                            TbxContact.Invoke(new Action(() => TbxContact.Text = booking.phone_num.ToString()));
                            dtpFrom.Invoke(new Action(() => dtpFrom.Value = DateTime.Parse(booking.FromDate)));
                            dtpTo.Invoke(new Action(() => dtpTo.Value = DateTime.Parse(booking.ToDate)));
                            lblId.Invoke(new Action(() => lblId.Text = vehicle.id.ToString()));
                            lblName1.Invoke(new Action(() => lblName1.Text = vehicle.name));
                            lblBrand.Invoke(new Action(() => lblBrand.Text = brandName));
                            lblPrice.Invoke(new Action(() => lblPrice.Text = vehicle.price.ToString()));
                            tbxDetail.Invoke(new Action(() => tbxDetail.Text = vehicle.details));
                            lblFuel.Invoke(new Action(() => lblFuel.Text = vehicle.fuel_type));
                            lblYear.Invoke(new Action(() => lblYear.Text = vehicle.model_year.ToString()));
                            lblSeating.Invoke(new Action(() => lblSeating.Text = vehicle.seating_capacity.ToString()));

                            if (DateTime.TryParse(vehicle.regDate, out DateTime parsedDate))
                            {
                                lblDate1.Invoke(new Action(() => lblDate1.Text = parsedDate.ToShortDateString()));
                            }
                            else
                            {
                                lblDate1.Invoke(new Action(() => lblDate1.Text = "Invalid Date"));
                            }

                            // Load image
                            pbxVehicle.Invoke(new Action(() => pbxVehicle.BackgroundImage = null));
                            string basePath = AppDomain.CurrentDomain.BaseDirectory;
                            string projectRoot = Directory.GetParent(basePath).Parent.Parent.FullName;
                            string imagePath = Path.Combine(projectRoot, vehicle.image);

                            if (File.Exists(imagePath))
                            {
                                pbxVehicle.Invoke(new Action(() => pbxVehicle.Image = Image.FromFile(imagePath)));
                            }
                            else
                            {
                                MessageBox.Show("Image file not found: " + imagePath);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Failed to retrieve Vehicle. Status code: " + vehicleResponse.StatusCode);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Failed to retrieve Booking. Status code: " + bookingResponse.StatusCode);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving data: " + ex.Message);
                }
            }
        }

        private async Task<string> GetBrandNameById(int brandId)
        {
            try
            {
                ApiClient client = new ApiClient("http://localhost:3000");
                List<Brand> brands = await client.GetAllBrandsAsync();
                Brand brand = brands.FirstOrDefault(b => b.id == brandId);
                if (brand != null)
                {
                    return brand.name;
                }
                else
                {
                    return "Brand not found";
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
        }

        private async void CustomerDetails_Load(object sender, EventArgs e)
        {
            if (Operation.checker)
            {
                await CheckID(Operation.idContent);
                Operation.checker = false;
            }
        }
    }
}
