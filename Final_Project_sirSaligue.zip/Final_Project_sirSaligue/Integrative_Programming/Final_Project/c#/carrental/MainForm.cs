﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace carrental
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnBrands_Click(object sender, EventArgs e)
        {
            SidePanel.Visible = true;

            SidePanel.Height = BtnBrands.Height;
            SidePanel.Top = BtnBrands.Top;
            Operation.AddForm(new Brands(), btnBooking);
        }

        private void btnVehicles_Click(object sender, EventArgs e)
        {
            SidePanel.Visible = true;

            SidePanel.Height = btnVehicles.Height;
            SidePanel.Top = btnVehicles.Top;
            Operation.AddForm(new Vehichles(), btnBooking);
        }

        private void BtnCustomer_Click(object sender, EventArgs e)
        {
            SidePanel.Visible = true;

            SidePanel.Height = BtnCustomer.Height;
            SidePanel.Top = BtnCustomer.Top;
            Operation.AddForm(new Customer(), btnBooking);
        }

        private void btnDash_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SidePanel.Visible = true;

            SidePanel.Height = btnBooking.Height;
            SidePanel.Top = btnBooking.Top;
            Operation.AddForm(new Booking(), btnBooking);
        }
    }
}
