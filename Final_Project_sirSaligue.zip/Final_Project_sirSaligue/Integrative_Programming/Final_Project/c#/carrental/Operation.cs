﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace carrental
{
    internal class Operation
    {
        public static void AddForm(Form f, Panel panel)
        {
            panel.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel.Controls.Add(f);
            f.Show();
        }

        public static int idContent = 0;
        public static bool checker = false;

        //account
        public static string username = "";
        public static string password = "";


    }

    public class UserAccount
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
    public class Brand
    {
        public int id { get; set; }
        public string name { get; set; }
        [JsonProperty("creation_date")]
        public string creationdate { get; set; }
        public override string ToString()
        {
            return name; // Display the brand name in ComboBox
        }
    }
    public class Vehicle
    {
        public int id { get; set; }
        public string name { get; set; }
        [JsonProperty("brand_id")]
        public int brand_id { get; set; }
        public string details { get; set; }
        public int price { get; set; }
        [JsonProperty("fuel_type")]
        public string fuel_type { get; set; }
        public int model_year { get; set; }
        public int seating_capacity { get; set; }
        [JsonProperty("image")]
        public string image { get; set; }
        [JsonProperty("reg_date")]
        public string regDate { get; set; }
        [JsonProperty("updation_date")]
        public string updation_date { get; set; }
    }
    public class VehicleId
    {
        public int id { get; set; }
        public string name { get; set; }
        [JsonProperty("brand_id")]
        public int brand_id { get; set; }
        public string details { get; set; }
        public int price { get; set; }
        [JsonProperty("fuel_type")]
        public string fuel_type { get; set; }
        public int model_year { get; set; }
        public int seating_capacity { get; set; }
        [JsonProperty("image")]
        public string image { get; set; }
        [JsonProperty("reg_date")]
        public string regDate { get; set; }
        [JsonProperty("updation_date")]
        public string updation_date { get; set; }
    }
    public class ApiClient
    {
        private readonly HttpClient _client;

        public ApiClient(string baseUrl)
        {
            _client = new HttpClient { BaseAddress = new Uri(baseUrl) };
        }

        public async Task<List<Brand>> GetAllBrandsAsync()
        {
            HttpResponseMessage response = await _client.GetAsync("/api/brands");
            response.EnsureSuccessStatusCode(); // Throw on error code.

            string responseBody = await response.Content.ReadAsStringAsync();
            List<Brand> brands = JsonConvert.DeserializeObject<List<Brand>>(responseBody);

            return brands;
        }
        public class Booking
        {
            public int id { get; set; }
            public string name { get; set; }
            [JsonProperty("VehicleId")]
            public int VehicleId { get; set; }
            [JsonProperty("address")]
            public string address { get; set; }
            public int phone_num { get; set; }
            [JsonProperty("FromDate")]
            public string FromDate { get; set; }
            [JsonProperty("ToDate")]
            public string ToDate { get; set; }
            [JsonProperty("Status")]
            public string Status { get; set; }
        }
        public class BookingId
        {
            public int id { get; set; }
            public string name { get; set; }
            [JsonProperty("VehicleId")]
            public int VehicleId { get; set; }
            [JsonProperty("address")]
            public string address { get; set; }
            public int phone_num { get; set; }
            [JsonProperty("cash")]
            public int cash { get; set; }
            [JsonProperty("FromDate")]
            public string FromDate { get; set; }
            [JsonProperty("ToDate")]
            public string ToDate { get; set; }
            [JsonProperty("Status")]
            public string Status { get; set; }
        }

    }
}
