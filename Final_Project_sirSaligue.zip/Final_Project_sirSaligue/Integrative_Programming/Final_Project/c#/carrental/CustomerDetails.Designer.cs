﻿namespace carrental
{
    partial class CustomerDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GbxCInfo = new System.Windows.Forms.GroupBox();
            this.btnBooked = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.TbxContact = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TbxAddress = new System.Windows.Forms.TextBox();
            this.TbxName = new System.Windows.Forms.TextBox();
            this.LblAddress = new System.Windows.Forms.Label();
            this.LblName = new System.Windows.Forms.Label();
            this.gbxview = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbxDetail = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.pbxVehicle = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDate1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblSeating = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblFuel = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblBrand = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblName1 = new System.Windows.Forms.Label();
            this.tbxCash = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.GbxCInfo.SuspendLayout();
            this.gbxview.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVehicle)).BeginInit();
            this.SuspendLayout();
            // 
            // GbxCInfo
            // 
            this.GbxCInfo.Controls.Add(this.tbxCash);
            this.GbxCInfo.Controls.Add(this.label2);
            this.GbxCInfo.Controls.Add(this.btnBooked);
            this.GbxCInfo.Controls.Add(this.btnDelete);
            this.GbxCInfo.Controls.Add(this.label13);
            this.GbxCInfo.Controls.Add(this.label4);
            this.GbxCInfo.Controls.Add(this.dtpTo);
            this.GbxCInfo.Controls.Add(this.dtpFrom);
            this.GbxCInfo.Controls.Add(this.TbxContact);
            this.GbxCInfo.Controls.Add(this.label3);
            this.GbxCInfo.Controls.Add(this.TbxAddress);
            this.GbxCInfo.Controls.Add(this.TbxName);
            this.GbxCInfo.Controls.Add(this.LblAddress);
            this.GbxCInfo.Controls.Add(this.LblName);
            this.GbxCInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GbxCInfo.ForeColor = System.Drawing.Color.Navy;
            this.GbxCInfo.Location = new System.Drawing.Point(13, 314);
            this.GbxCInfo.Margin = new System.Windows.Forms.Padding(4);
            this.GbxCInfo.Name = "GbxCInfo";
            this.GbxCInfo.Padding = new System.Windows.Forms.Padding(4);
            this.GbxCInfo.Size = new System.Drawing.Size(1184, 293);
            this.GbxCInfo.TabIndex = 5;
            this.GbxCInfo.TabStop = false;
            this.GbxCInfo.Text = "Customer Information";
            // 
            // btnBooked
            // 
            this.btnBooked.BackColor = System.Drawing.Color.LimeGreen;
            this.btnBooked.Location = new System.Drawing.Point(793, 215);
            this.btnBooked.Name = "btnBooked";
            this.btnBooked.Size = new System.Drawing.Size(131, 50);
            this.btnBooked.TabIndex = 104;
            this.btnBooked.Text = "Booked";
            this.btnBooked.UseVisualStyleBackColor = false;
            this.btnBooked.Click += new System.EventHandler(this.btnBooked_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.IndianRed;
            this.btnDelete.Location = new System.Drawing.Point(963, 216);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(136, 49);
            this.btnDelete.TabIndex = 103;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(636, 117);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 16);
            this.label13.TabIndex = 12;
            this.label13.Text = "ToDate:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(620, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "FromDate:";
            // 
            // dtpTo
            // 
            this.dtpTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTo.Location = new System.Drawing.Point(706, 112);
            this.dtpTo.Margin = new System.Windows.Forms.Padding(4);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(232, 22);
            this.dtpTo.TabIndex = 10;
            // 
            // dtpFrom
            // 
            this.dtpFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFrom.Location = new System.Drawing.Point(706, 80);
            this.dtpFrom.Margin = new System.Windows.Forms.Padding(4);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(232, 22);
            this.dtpFrom.TabIndex = 9;
            // 
            // TbxContact
            // 
            this.TbxContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxContact.Location = new System.Drawing.Point(283, 138);
            this.TbxContact.Margin = new System.Windows.Forms.Padding(4);
            this.TbxContact.Name = "TbxContact";
            this.TbxContact.Size = new System.Drawing.Size(232, 22);
            this.TbxContact.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(178, 144);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Contact No.:";
            // 
            // TbxAddress
            // 
            this.TbxAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxAddress.Location = new System.Drawing.Point(283, 109);
            this.TbxAddress.Margin = new System.Windows.Forms.Padding(4);
            this.TbxAddress.Name = "TbxAddress";
            this.TbxAddress.Size = new System.Drawing.Size(232, 22);
            this.TbxAddress.TabIndex = 6;
            // 
            // TbxName
            // 
            this.TbxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxName.Location = new System.Drawing.Point(283, 77);
            this.TbxName.Margin = new System.Windows.Forms.Padding(4);
            this.TbxName.Name = "TbxName";
            this.TbxName.Size = new System.Drawing.Size(232, 22);
            this.TbxName.TabIndex = 2;
            // 
            // LblAddress
            // 
            this.LblAddress.AutoSize = true;
            this.LblAddress.Location = new System.Drawing.Point(202, 115);
            this.LblAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblAddress.Name = "LblAddress";
            this.LblAddress.Size = new System.Drawing.Size(73, 16);
            this.LblAddress.TabIndex = 1;
            this.LblAddress.Text = "Address: ";
            // 
            // LblName
            // 
            this.LblName.AutoSize = true;
            this.LblName.Location = new System.Drawing.Point(217, 86);
            this.LblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(52, 16);
            this.LblName.TabIndex = 0;
            this.LblName.Text = "Name:";
            // 
            // gbxview
            // 
            this.gbxview.Controls.Add(this.panel1);
            this.gbxview.Controls.Add(this.lblPrice);
            this.gbxview.Controls.Add(this.pbxVehicle);
            this.gbxview.Controls.Add(this.label10);
            this.gbxview.Controls.Add(this.lblId);
            this.gbxview.Controls.Add(this.label9);
            this.gbxview.Controls.Add(this.label1);
            this.gbxview.Controls.Add(this.lblDate1);
            this.gbxview.Controls.Add(this.label6);
            this.gbxview.Controls.Add(this.lblSeating);
            this.gbxview.Controls.Add(this.label7);
            this.gbxview.Controls.Add(this.lblYear);
            this.gbxview.Controls.Add(this.label8);
            this.gbxview.Controls.Add(this.lblFuel);
            this.gbxview.Controls.Add(this.label11);
            this.gbxview.Controls.Add(this.lblBrand);
            this.gbxview.Controls.Add(this.label12);
            this.gbxview.Controls.Add(this.lblName1);
            this.gbxview.Location = new System.Drawing.Point(189, 12);
            this.gbxview.Name = "gbxview";
            this.gbxview.Size = new System.Drawing.Size(804, 293);
            this.gbxview.TabIndex = 107;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.tbxDetail);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(447, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(313, 259);
            this.panel1.TabIndex = 94;
            // 
            // tbxDetail
            // 
            this.tbxDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxDetail.Location = new System.Drawing.Point(23, 56);
            this.tbxDetail.Multiline = true;
            this.tbxDetail.Name = "tbxDetail";
            this.tbxDetail.Size = new System.Drawing.Size(267, 185);
            this.tbxDetail.TabIndex = 107;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 16);
            this.label5.TabIndex = 90;
            this.label5.Text = "Details:";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(69, 255);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(0, 16);
            this.lblPrice.TabIndex = 104;
            // 
            // pbxVehicle
            // 
            this.pbxVehicle.Location = new System.Drawing.Point(217, 53);
            this.pbxVehicle.Name = "pbxVehicle";
            this.pbxVehicle.Size = new System.Drawing.Size(204, 146);
            this.pbxVehicle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxVehicle.TabIndex = 80;
            this.pbxVehicle.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 255);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 16);
            this.label10.TabIndex = 103;
            this.label10.Text = "Price:";
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(46, 26);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(0, 16);
            this.lblId.TabIndex = 102;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 16);
            this.label9.TabIndex = 101;
            this.label9.Text = "Id:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 87;
            this.label1.Text = "Name:";
            // 
            // lblDate1
            // 
            this.lblDate1.AutoSize = true;
            this.lblDate1.Location = new System.Drawing.Point(121, 223);
            this.lblDate1.Name = "lblDate1";
            this.lblDate1.Size = new System.Drawing.Size(0, 16);
            this.lblDate1.TabIndex = 100;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 16);
            this.label6.TabIndex = 88;
            this.label6.Text = "Brand:";
            // 
            // lblSeating
            // 
            this.lblSeating.AutoSize = true;
            this.lblSeating.Location = new System.Drawing.Point(140, 187);
            this.lblSeating.Name = "lblSeating";
            this.lblSeating.Size = new System.Drawing.Size(0, 16);
            this.lblSeating.TabIndex = 99;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 118);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 16);
            this.label7.TabIndex = 89;
            this.label7.Text = "Fuel Type:";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(107, 156);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(0, 16);
            this.lblYear.TabIndex = 98;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 156);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 16);
            this.label8.TabIndex = 91;
            this.label8.Text = "Model Year:";
            // 
            // lblFuel
            // 
            this.lblFuel.AutoSize = true;
            this.lblFuel.Location = new System.Drawing.Point(99, 118);
            this.lblFuel.Name = "lblFuel";
            this.lblFuel.Size = new System.Drawing.Size(0, 16);
            this.lblFuel.TabIndex = 97;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 187);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 16);
            this.label11.TabIndex = 92;
            this.label11.Text = "Seating Capacity:";
            // 
            // lblBrand
            // 
            this.lblBrand.AutoSize = true;
            this.lblBrand.Location = new System.Drawing.Point(74, 86);
            this.lblBrand.Name = "lblBrand";
            this.lblBrand.Size = new System.Drawing.Size(0, 16);
            this.lblBrand.TabIndex = 96;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(22, 223);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 16);
            this.label12.TabIndex = 93;
            this.label12.Text = "Register Date:";
            // 
            // lblName1
            // 
            this.lblName1.AutoSize = true;
            this.lblName1.Location = new System.Drawing.Point(74, 53);
            this.lblName1.Name = "lblName1";
            this.lblName1.Size = new System.Drawing.Size(0, 16);
            this.lblName1.TabIndex = 95;
            // 
            // tbxCash
            // 
            this.tbxCash.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCash.Location = new System.Drawing.Point(286, 168);
            this.tbxCash.Margin = new System.Windows.Forms.Padding(4);
            this.tbxCash.Name = "tbxCash";
            this.tbxCash.Size = new System.Drawing.Size(232, 22);
            this.tbxCash.TabIndex = 106;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(223, 174);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 105;
            this.label2.Text = "Cash:";
            // 
            // CustomerDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1203, 620);
            this.Controls.Add(this.gbxview);
            this.Controls.Add(this.GbxCInfo);
            this.Name = "CustomerDetails";
            this.Text = "CustomerDetails";
            this.Load += new System.EventHandler(this.CustomerDetails_Load);
            this.GbxCInfo.ResumeLayout(false);
            this.GbxCInfo.PerformLayout();
            this.gbxview.ResumeLayout(false);
            this.gbxview.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVehicle)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GbxCInfo;
        private System.Windows.Forms.Button btnBooked;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpTo;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.TextBox TbxContact;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TbxAddress;
        private System.Windows.Forms.TextBox TbxName;
        private System.Windows.Forms.Label LblAddress;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.Panel gbxview;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tbxDetail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.PictureBox pbxVehicle;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDate1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblSeating;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblFuel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblBrand;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblName1;
        private System.Windows.Forms.TextBox tbxCash;
        private System.Windows.Forms.Label label2;
    }
}