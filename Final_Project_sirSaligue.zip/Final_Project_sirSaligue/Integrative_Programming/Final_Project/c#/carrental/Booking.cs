﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static carrental.ApiClient;

namespace carrental
{
    public partial class Booking : Form
    {
        public Booking()
        {
            InitializeComponent();
        }

        private void dtpBooking_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int selectedrow;
                selectedrow = e.RowIndex;
                DataGridViewRow row = dtpBooking.Rows[selectedrow];

                Operation.idContent = int.Parse(row.Cells[0].Value.ToString());
                Operation.checker = true;

                CustomerDetails ii = new CustomerDetails();
                ii.Show();
                this.Hide();


            }
            catch (Exception c) { MessageBox.Show(c.Message); }
        }
        private HttpClient client = new HttpClient();
        private string apiUrl = "http://localhost:3000/api/booking";
        private async Task LoadBooking()
        {
            try
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);
                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    // Deserialize JSON response to list of Booking objects
                    var bookings = JsonConvert.DeserializeObject<List<BookingId>>(responseBody);
                    // Bind the bookings to your dtpBooking control
                    dtpBooking.DataSource = bookings;
                }
                else
                {
                    MessageBox.Show($"Failed to load bookings. Status code: {response.StatusCode}");
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred while sending the request: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private async void Booking_Load(object sender, EventArgs e)
        {
            await LoadBooking();
        }
        private async Task Search()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    string id = tbxSearch.Text.Trim();
                    string url = string.IsNullOrEmpty(id) ? "http://localhost:3000/api/booking" : $"http://localhost:3000/api/booking/{id}";

                    HttpResponseMessage response = await client.GetAsync(url);

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonResponse = await response.Content.ReadAsStringAsync();
                        if (string.IsNullOrEmpty(id))
                        {
                            List<Vehicle> vehicles = JsonConvert.DeserializeObject<List<Vehicle>>(jsonResponse);
                            dtpBooking.DataSource = vehicles;
                        }
                        else
                        {
                            Vehicle vehicle = JsonConvert.DeserializeObject<Vehicle>(jsonResponse);
                            dtpBooking.DataSource = new List<Vehicle> { vehicle };
                        }
                    }
                    else
                    {
                        dtpBooking.DataSource = null; // Clear the DataGridView if request fails
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void tbxSearch_TextChanged(object sender, EventArgs e)
        {
            await Search();
        }
    }
}
